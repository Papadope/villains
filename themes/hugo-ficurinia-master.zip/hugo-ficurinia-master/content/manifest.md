---
title: Manifest
layout: manifest
outputs:
 - "json"
norss: true
nosearch: true
---
